-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 15, 2021 at 05:44 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newsportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

DROP TABLE IF EXISTS `tblcategory`;
CREATE TABLE IF NOT EXISTS `tblcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(200) DEFAULT NULL,
  `Description` mediumtext,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL,
  `Is_Active` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `CategoryName`, `Description`, `PostingDate`, `UpdationDate`, `Is_Active`) VALUES
(3, 'Sports', 'Related to sports news', '2018-06-06 10:35:09', '2018-06-14 11:11:55', 1),
(5, 'Entertainment', 'Entertainment related  News', '2018-06-14 05:32:58', '2018-06-14 05:33:41', 1),
(6, 'Politics', 'Politics', '2018-06-22 15:46:09', '0000-00-00 00:00:00', 1),
(7, 'Business', 'Business', '2018-06-22 15:46:22', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblcomments`
--

DROP TABLE IF EXISTS `tblcomments`;
CREATE TABLE IF NOT EXISTS `tblcomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postId` char(11) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `comment` mediumtext,
  `postingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

DROP TABLE IF EXISTS `tblpages`;
CREATE TABLE IF NOT EXISTS `tblpages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `PageName` varchar(200) DEFAULT NULL,
  `PageTitle` mediumtext,
  `Description` longtext,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `PageTitle`, `Description`, `PostingDate`, `UpdationDate`) VALUES
(1, 'aboutus', 'About News Portal', '<font color=\"#7b8898\" face=\"Mercury SSm A, Mercury SSm B, Georgia, Times, Times New Roman, Microsoft YaHei New, Microsoft Yahei, å¾®è½¯é›…é»‘, å®‹ä½“, SimSun, STXihei, åŽæ–‡ç»†é»‘, serif\"><span style=\"font-size: 26px;\">BEST NEWS IN SRILANKA</span></font><br>', '2018-06-30 18:01:03', '2021-01-15 16:33:56'),
(2, 'contactus', 'Contact Details', '<p><br></p><p><b>Address :&nbsp; </b>COLOMBO SRILANKA</p><p><b>Phone Number : </b>+94 -123456789</p><p><b>Email -id : </b>Lknews@gmail.com</p>', '2018-06-30 18:01:36', '2021-01-15 16:31:01');

-- --------------------------------------------------------

--
-- Table structure for table `tblposts`
--

DROP TABLE IF EXISTS `tblposts`;
CREATE TABLE IF NOT EXISTS `tblposts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `PostTitle` longtext,
  `CategoryId` int(11) DEFAULT NULL,
  `SubCategoryId` int(11) DEFAULT NULL,
  `PostDetails` longtext CHARACTER SET utf8,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Is_Active` int(1) DEFAULT NULL,
  `PostUrl` mediumtext,
  `PostImage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblposts`
--

INSERT INTO `tblposts` (`id`, `PostTitle`, `CategoryId`, `SubCategoryId`, `PostDetails`, `PostingDate`, `UpdationDate`, `Is_Active`, `PostUrl`, `PostImage`) VALUES
(13, 'à¶¢à¶±à¶´à¶­à·’ à¶¶à·ƒà·Š à¶‘à¶šà·š à¶ºà¶ºà·’..', 6, 7, '<p style=\"margin-bottom: 10px; font-size: 16px; color: rgb(33, 33, 33); font-family: &quot;malithi web&quot;, Arial, Helvetica, sans-serif;\">à¶šà·œà·…à¶¹ à¶±à¶œà¶»à¶º à¶†à·à·Šâ€à¶»à·’à¶­ à·€à·à·„à¶± à¶­à¶¯à¶¶à¶¯à¶ºà¶§ à¶´à·’à·…à·’à¶ºà¶¸à¶šà·Š à¶½à·™à·ƒ à·„à¶³à·”à¶±à·Šà·€à· à¶¯à·™à¶± â€œPark &amp; Rideâ€ à¶¶à·ƒà·Š à¶»à¶® à·ƒà·šà·€à·à·€à·š à¶´à·…à¶¸à·” à¶…à¶¯à·’à¶ºà¶» à¶¢à¶±à·à¶°à·’à¶´à¶­à·’ à¶œà·à¶¨à·à¶·à¶º à¶»à·à¶¢à¶´à¶šà·Šà·‚ à¶¸à·à¶­à·’à¶­à·”à¶¸à·à¶œà·š à¶´à·Šâ€à¶»à¶°à·à¶±à¶­à·Šà·€à¶ºà·™à¶±à·Š à¶šà·œà¶§à·Šà¶§à·à·€, à¶¸à·à¶šà·”à¶¹à·”à¶» à¶¶à·„à·”à·€à·’à¶° à¶´à·Šâ€à¶»à·€à·à·„à¶± à¶¸à¶°à·Šâ€à¶ºà·ƒà·Šà¶®à·à¶±à¶º à¶šà·šà¶±à·Šà¶¯à·Šâ€à¶» à¶šà¶»à¶œà¶±à·’à¶¸à·’à¶±à·Š à¶…à¶¯ (15) à¶†à¶»à¶¸à·Šà¶· à¶šà·™à¶»à·’à¶«.</p><p style=\"margin-bottom: 10px; font-size: 16px; color: rgb(33, 33, 33); font-family: &quot;malithi web&quot;, Arial, Helvetica, sans-serif;\">à¶¸à·à¶§à¶»à·Š à¶»à¶®à¶ºà·™à¶±à·Š à·ƒà·„ à¶ºà¶­à·”à¶»à·” à¶´à·à¶¯à·’à¶ºà·™à¶±à·Š à¶œà¶¸à¶±à·Š à¶œà¶±à·Šà¶±à· à¶¸à¶œà·“à¶±à·Š à·ƒà¶³à·„à· à·ƒà·”à·€à¶´à·„à·ƒà·”, à¶†à¶»à¶šà·Šà·‚à·’à¶­ à¶´à·œà¶¯à·” à¶´à·Šâ€à¶»à·€à·à·„à¶± à¶¶à·ƒà·Šà¶»à¶® à·ƒà·šà·€à·à·€à¶šà·Š à·ƒà·à¶´à¶ºà·“à¶¸ à¶¸à¶œà·’à¶±à·Š à¶šà·œà·…à¶¹ à·ƒà·„ à¶­à¶¯à·à·ƒà¶±à·Šà¶± à¶±à¶œà¶» à·€à¶½à¶§ à¶œà¶¸à¶±à·Š à¶šà¶»à¶± à·€à·à·„à¶± à·ƒà¶‚à¶›à·Šâ€à¶ºà·à·€ à¶…à¶©à·” à¶šà·’à¶»à·“à¶¸ à¶¸à·™à·„à·’ à¶…à¶»à¶¸à·”à¶«à¶ºà·’. à¶´à¶»à·’à·ƒà¶» à¶¯à·–à·‚à¶«à¶º, à·€à·à¶ºà·€à¶± à¶šà·à¶½à¶º à·ƒà·„ à¶¸à¶œà·“à¶±à·Šà¶œà·š à¶¸à·à¶±à·ƒà·’à¶š à¶´à·“à¶©à¶±à¶º à¶…à·€à¶¸ à¶šà·’à¶»à·“à¶¸ à¶¯ à¶…à¶´à·šà¶šà·Šà·‚à· à¶šà·™à¶»à·š.</p><p style=\"margin-bottom: 10px; font-size: 16px; color: rgb(33, 33, 33); font-family: &quot;malithi web&quot;, Arial, Helvetica, sans-serif;\">à¶†à·ƒà¶± à¶œà¶«à¶±à¶§ à¶¸à¶œà·“à¶±à·Š à¶»à·à¶œà·™à¶± à¶ºà·à¶¸à¶§ à·ƒà·”à¶›à·à¶´à¶·à·à¶œà·“ à¶¶à·ƒà·Šà¶»à¶® à¶´à¶¸à¶«à¶šà·Š à¶ºà·œà¶¯à· à¶œà·à¶±à·š. à¶…à¶ºà¶šà·™à¶»à·™à¶± à¶¸à·”à¶¯à¶½ à·ƒà·à¶¸à·à¶±à·Šâ€à¶º à¶¶à·ƒà·Š à¶»à¶® à¶œà·à·ƒà·Šà¶­à·”à·€ à¶¸à·™à¶±à·Š à¶¯à·™à¶œà·”à¶«à¶ºà¶šà·’. à¶±à·à·€à¶­à·”à¶¸à·Šà¶´à·œà·… à·ƒà·“à¶¸à·’à¶­ à·ƒà¶‚à¶›à·Šâ€à¶ºà·à·€à¶šà·’à¶±à·Š à¶´à¶¸à¶«à¶šà·Š à¶¸à¶œà·“à¶±à·Š à¶±à¶‚à·€à· à¶œà·à¶±à·“à¶¸, à¶…à¶©à·” à¶šà·à¶½à¶ºà¶šà·’à¶±à·Š à¶œà¶¸à¶±à·à¶±à·Šà¶­à¶º à¶šà¶»à· à·…à¶Ÿà·à·€à·“à¶¸, à¶†à¶ à·à¶»à·à·“à¶½à·“, à·ƒà·”à·„à¶¯à·à·“à¶½à·“ à·„à· à¶†à¶šà¶»à·Šà·à¶«à·“à¶º à¶´à·Šâ€à¶»à·€à·à·„à¶± à·ƒà·šà·€à·à·€à¶šà·Š à·ƒà·à¶½à·ƒà·“à¶¸, à¶­à·à¶šà·Šà·‚à¶«à¶º à¶‹à¶´à¶ºà·à¶œà·“ à¶šà¶»à¶œà·™à¶± à¶¯à·’à¶±à¶´à¶­à· à¶šà·™à¶»à·™à¶± à¶´à·ƒà·”à·€à·’à¶´à¶»à¶¸ à·ƒà·„ Clock Wise à·„à· Anti Clock Wise à¶œà¶¸à¶±à·Š à·€à¶»à·Šà¶œ à¶¯à·™à¶šà¶šà·Š à¶šà·Šâ€à¶»à·’à¶ºà·à¶­à·Šà¶¸à¶š à·€à·“à¶¸ à·€à·à¶©à·ƒà¶§à·„à¶±à¶§ à¶…à¶ºà¶­à·Š à·€à·š.</p>', '2021-01-15 13:47:51', '2021-01-15 14:09:03', 1, 'à¶¢à¶±à¶´à¶­à·’-à¶¶à·ƒà·Š-à¶‘à¶šà·š-à¶ºà¶ºà·’..', '2b49d84bc655036abb8d3e1e34ce8c88.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubcategory`
--

DROP TABLE IF EXISTS `tblsubcategory`;
CREATE TABLE IF NOT EXISTS `tblsubcategory` (
  `SubCategoryId` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryId` int(11) DEFAULT NULL,
  `Subcategory` varchar(255) DEFAULT NULL,
  `SubCatDescription` mediumtext,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL,
  `Is_Active` int(1) DEFAULT NULL,
  PRIMARY KEY (`SubCategoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsubcategory`
--

INSERT INTO `tblsubcategory` (`SubCategoryId`, `CategoryId`, `Subcategory`, `SubCatDescription`, `PostingDate`, `UpdationDate`, `Is_Active`) VALUES
(4, 3, 'Cricket', 'Cricket\r\n\r\n', '2018-06-30 09:00:43', '0000-00-00 00:00:00', 1),
(5, 3, 'Football', 'Football', '2018-06-30 09:00:58', '0000-00-00 00:00:00', 1),
(6, 5, 'Television', 'TeleVision', '2018-06-30 18:59:22', '0000-00-00 00:00:00', 1),
(7, 6, 'National', 'National', '2018-06-30 19:04:29', '0000-00-00 00:00:00', 1),
(8, 6, 'International', 'International', '2018-06-30 19:04:43', '0000-00-00 00:00:00', 1),
(9, 7, 'India', 'India', '2018-06-30 19:08:42', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `user_password` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `user_password`) VALUES
(1, 'admin', 12345);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
